/**
 * content.js — Lead Finder LinkedIn Injector content script
 * ===========================================================
 * Runs only on https://www.linkedin.com/in/* profile pages.
 *
 * Strategy (per user requirement — logged in with Premium, sees everything):
 *   1. PRIMARY: read the real DOM, not marketing meta tags. The user is
 *      logged in with Premium so the data is fully visible to them.
 *   2. The top card has the name (<h1 class="top-card-layout__title">) and
 *      the current company (data-section="currentPositionsDetails" → span).
 *   3. The Experience & Education section has the full history in
 *      <li class="profile-section-card"> items, each with an <h3> (company)
 *      and an <h4> (title). For 1st-degree connections and Premium users
 *      with "Who Viewed My Profile" access, titles are not blurred.
 *   4. The current title is often between the h1 and the company span
 *      (e.g. "EVP and Chief Financial Officer, The Boeing Company" appears
 *      as a subheading in the top card).
 *   5. FALLBACK: leave fields empty and let the user fill the form manually.
 *      The popup is ALWAYS shown per the user's requirement (no silent path).
 *
 * Notes:
 *   - DO NOT extract the headline (per user — unreliable personal descriptor).
 *   - MutationObserver + Re-scan button let the user retry extraction when
 *     LinkedIn's lazy-loaded content has finished rendering.
 *
 * Communicates with popup via chrome.runtime.sendMessage / onMessage.
 */

(() => {
  "use strict";

  // ── Logging helper (so the user can open DevTools and see why extraction failed)
  const log = (...args) => console.log("[lead-finder/cs]", ...args);
  const warn = (...args) => console.warn("[lead-finder/cs]", ...args);

  // ── Slug extraction (mirror of server's _extract_linkedin_slug) ───────────
  const extractSlug = (url) => {
    try {
      const u = new URL(url);
      const m = u.pathname.match(/^\/in\/([^/?#]+)/);
      return m ? m[1] : "";
    } catch {
      return "";
    }
  };

  // ── Extract the full name from the profile ────────────────────────────────
  // The current LinkedIn DOM doesn't use <h1> for the name. The first
  // <h2> in <main> is the name. (LinkedIn uses semantic heading levels
  // and the profile name is the page's "title".)
  // Fall back to og:title if no <h2> is found.
  const extractName = () => {
    const mainH2 = document.querySelector("main h2");
    if (mainH2) {
      const t = (mainH2.textContent || "").trim();
      if (t) return t;
    }
    // Fallback: og:title (always present). Format: "Breslin Juan - LinkedIn"
    const og = document.querySelector('meta[property="og:title"]');
    if (og) {
      return (og.getAttribute("content") || "").replace(/\s*[|\-–]\s*LinkedIn\s*$/i, "").trim();
    }
    return "";
  };

  // ── Extract the current company from the top card ─────────────────────────
  // LinkedIn's modern top card has a "Current company" line below the name.
  // The text appears as the first segment in the profile header. We look
  // for the company link's text — usually a short string immediately after
  // the name h2.
  const extractCurrentCompanyFromTopCard = () => {
    const main = document.querySelector("main");
    if (!main) return "";
    // Walk the immediate text-bearing elements after the name h2.
    const nameH2 = main.querySelector("h2");
    if (!nameH2) return "";
    // The company is usually in the next sibling div/section.
    let node = nameH2.parentElement;
    while (node) {
      node = node.nextElementSibling;
      if (!node) break;
      const link = node.querySelector("a[href*='/company/']");
      if (link) {
        const text = (link.textContent || "").trim();
        // The link text usually contains the company name (possibly with
        // a logo alt text prefix). Take the longest meaningful chunk.
        const parts = text.split(/\s*[·•]\s*/).map(s => s.trim()).filter(Boolean);
        if (parts.length > 0) return parts[0];
      }
    }
    return "";
  };

  // ── Extract the location from the top card ─────────────────────────────────
  // Location appears in the top card near the bottom. Format is usually
  // "City, State, Country" or "City Metropolitan Area".
  const extractLocation = () => {
    const main = document.querySelector("main");
    if (!main) return "";
    // Look for a text node matching a "City, State" or "Metropolitan Area"
    // pattern. Skip elements that look like company names.
    const candidates = main.querySelectorAll("span, div, p");
    for (const el of candidates) {
      const direct = Array.from(el.childNodes)
        .filter(n => n.nodeType === Node.TEXT_NODE)
        .map(n => (n.textContent || "").trim())
        .filter(Boolean)
        .join(" ");
      if (!direct) continue;
      // "City, State" or "City, State, Country"
      if (/^[A-Z][a-zA-Z\.\-]+(?:\s[A-Z][a-zA-Z\.\-]+)*(?:,\s*[A-Z][a-zA-Z\.\-]+){1,3}$/.test(direct)) {
        return direct;
      }
      // "Metropolitan Area" or "Greater City Area"
      if (/^[A-Z][a-zA-Z\.\-]+(?:\s[A-Z][a-zA-Z\.\-]+)*\s+(Metropolitan|Greater)\s+[A-Z]/.test(direct)) {
        return direct;
      }
    }
    return "";
  };

  // ── Find the LATEST experience role ───────────────────────────────────────
  // Per user requirement: we only need the current/most recent role.
  // Per observation: LinkedIn shows the CURRENT role as a <div> (always
  // visible), and older roles as <li> items (often hidden in a collapsed
  // "see more" section). If we just pick the first <li>, we get the wrong
  // (older) role. The reliable signal: the current role is the FIRST
  // <div> inside the Experience section that contains "Present" in its
  // date range. Older roles end in a specific year (e.g. "Jul 2023"),
  // not "Present".
  //
  // Strategy:
  //   1. Find the Experience <h2> section.
  //   2. Look for <div>s that contain "Present" in their text and have
  //      reasonable length (single role, not the whole section).
  //   3. Return the SHORTEST one with "Present" — that's the current
  //      role (it has the least history behind it).
  //   4. Fall back to the first <li> if no Present-role <div> is found.
  const findLatestExperienceItem = () => {
    // FIX rev-20260724-NNNN: LinkedIn's section heading is "Experience & Education"
    // on some profiles (combined section), or just "Experience" on others. Use
    // startsWith() so both match, instead of exact equality which only matched
    // bare "Experience" and silently returned null on combined sections. (This
    // was the cause of the Nicole LaMotte "Manager, / Technical Recruiting"
    // symptom — the heading check returned null, so the parser fell through
    // to a wrong <ul> lower in the DOM tree.)
    const expH2 = Array.from(document.querySelectorAll("h2"))
      .find(h => {
        const t = h.textContent.trim();
        return t === "Experience" || t.startsWith("Experience &") || t.startsWith("Experience,");
      });
    if (!expH2) return null;

    const section = expH2.closest("section") || expH2.parentElement;

    // Strategy 2 (preferred when <ul> exists): pick the first <li> directly.
    // This handles the common case where each role is in a <li> child of a <ul>
    // (most 1st/2nd-degree profiles). Picking the first <li> gives the latest
    // role, and the <a href="/company/..."> link is reachable on the <li>.
    //
    // CRITICAL: At each ancestor level, only accept a <ul> that LOOKS like the
    // experience list. Heuristic: its first <li> must contain BOTH a date
    // substring (e.g. "Jan 2026") AND a /company/ link. Without this check,
    // the first <ul> we find may be a skills/highlights sub-list with no
    // dates and no company link, and we'd return its <li> as the experience.
    const monthRe2 = /(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+\d{4}|\d{4}\s*[-–]/;
    if (section) {
      let container = section;
      for (let d = 0; d < 6 && container; d++) {
        const uls = Array.from(container.querySelectorAll(":scope > ul, :scope > ol"));
        for (const ul of uls) {
          const firstLi = ul.querySelector(":scope > li");
          if (!firstLi) continue;
          const liText = (firstLi.textContent || "");
          const hasDate = monthRe2.test(liText);
          const hasCompanyLink = !!firstLi.querySelector('a[href*="/company/"]');
          // DIAGNOSTIC: log every <ul> we see and why we accept/reject it
          console.log(
            `[lead-finder/cs] depth=${d} ul class="${ul.className || ''}" firstLi text="${liText.slice(0, 60)}" hasDate=${hasDate} hasCompanyLink=${hasCompanyLink} -> ${(hasDate || hasCompanyLink) ? 'ACCEPT' : 'SKIP'}`,
          );
          if (!hasDate && !hasCompanyLink) continue; // skip skills/highlights lists
          // Found the experience list. Extract the company link.
          const companyLink = firstLi.querySelector('a[href*="/company/"]');
          let company = "";
          if (companyLink) {
            company = (companyLink.textContent || "").trim()
              || companyLink.getAttribute("aria-label")
              || companyLink.getAttribute("title")
              || "";
            if (!company) {
              const allSpans = companyLink.querySelectorAll("span");
              for (const s of allSpans) {
                const t = (s.textContent || "").trim();
                if (t && t.length > 1) { company = t; break; }
              }
            }
          }
          console.log(
            `[lead-finder/cs] PICKED depth=${d} firstLi text="${firstLi.textContent.slice(0, 80)}" companyFromLink="${company}"`,
          );
          return {
            text: firstLi.textContent || "",
            companyFromLink: company,
            isLi: true,
          };
        }
        container = container.parentElement;
      }
    }

    // Strategy 1 (fallback for div-only profiles): 3rd-degree connections
    // sometimes render experience as flat <div> blocks (no <ul>). Find the
    // smallest div containing BOTH a date AND "Present". Walk up to the
    // closest <li> if one exists, to get the company link.
    const monthRe = /(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+\d{4}|\d{4}\s*[-–]/;
    if (section) {
      const candidates = Array.from(section.querySelectorAll("div"))
        .filter(div => {
          const t = (div.textContent || "");
          return monthRe.test(t) && /\bPresent\b/.test(t);
        })
        .filter(div => (div.textContent || "").length < 800)
        .filter(div => {
          // Skip divs that contain other Present-containing divs.
          const inner = div.querySelectorAll("div");
          for (const child of inner) {
            if (child === div) continue;
            const ct = child.textContent || "";
            if (monthRe.test(ct) && /\bPresent\b/.test(ct) && ct.length < 800) {
              return false;
            }
          }
          return true;
        });
      candidates.sort((a, b) => a.textContent.length - b.textContent.length);
      if (candidates.length > 0) {
        const picked = candidates[0];
        // If the picked div is inside an <li>, walk up to the <li> to find
        // the company link. The company link lives on the <li>, not the
        // inner div.
        const hostLi = picked.closest("li");
        const linkContainer = hostLi || picked;
        const companyLink = linkContainer.querySelector('a[href*="/company/"]');
        let company = "";
        if (companyLink) {
          company = (companyLink.textContent || "").trim()
            || companyLink.getAttribute("aria-label")
            || companyLink.getAttribute("title")
            || "";
          if (!company) {
            const allSpans = companyLink.querySelectorAll("span");
            for (const s of allSpans) {
              const t = (s.textContent || "").trim();
              if (t && t.length > 1) { company = t; break; }
            }
          }
        }
        return {
          text: picked.textContent || "",
          companyFromLink: company,
          isLi: !!hostLi,
        };
      }
    }

    return null;
  };

  // ── Extract the latest experience (only the current role) ─────────────────
  // Per user: just the most recent role, not the full history.
  const extractExperience = () => {
    const item = findLatestExperienceItem();
    if (!item) return [];
    const parsed = parseExperienceItem(item.text);
    if (!parsed || !parsed.title) {
      // No parseable title — return a stub so the user can still see the
      // company link in the audit.
      if (item.companyFromLink) {
        return [{
          company: item.companyFromLink,
          title: "",
          started_at: "",
          ended_at: "",
          is_current: false,
          source: "plugin",
          linkedin_slug: extractSlug(window.location.href),
        }];
      }
      return [];
    }
    // For format A (<li>), the parser doesn't see the company in the text —
    // use the company link's text. For format B (<div>), the parser
    // already extracted the company from the text.
    let company = parsed.company || item.companyFromLink;
    return [{
      company: company || "",
      title: parsed.title,
      started_at: parsed.started_at || "",
      ended_at: parsed.ended_at || "",
      is_current: !!parsed.is_current,
      source: "plugin",
      linkedin_slug: extractSlug(window.location.href),
    }];
  };

  // ── Parse a single experience <li> or <div>'s textContent ─────────────────
  // The text content has no internal separators we can rely on. Observed
  // formats (from real profiles logged in with Premium):
  //
  //   A. <li> (most profiles, 8/9):
  //      "OperationsJan 2022 - Present · 4 yrs 7 mos"
  //      "Director of New Development May 2020 - Present · 6 yrs 3 mosLos Angeles, California, United States"
  //      "Chief Executive OfficerFull-timeMar 2024 - Present · 2 yrs 5 mos"
  //      → title=before-date, company=N/A (in inner link), date=…, location=after-duration
  //
  //   B. <div> (3rd-degree connections, 1/9):
  //      "Chief Financial OfficerBoeingAug 2025 - Present · 1 yrSeattle, Washington, United States"
  //      "CFO Lockheed Martin · Full-timeJan 2022 - Apr 2025 · 3 yrs 4 mosBethesda, Maryland, United States"
  //      → title=before-company, company=before-date, date=…, location=after-duration
  //
  // Algorithm:
  //   1. Find the date range (most reliable signal: "Month YYYY" or "YYYY"
  //      preceded by start-of-string, space, or lowercase letter).
  //   2. If format B (with company in text), the company is between the
  //      title and the date. Look for a known company-name pattern
  //      (multi-word capitalized phrase, possibly with "Inc.", "LLC",
  //      "Corp", "Ltd", or "· Full-time" suffix).
  //   3. Title = text before the company (format B) or directly before the
  //      date (format A).
  //   4. After the date, strip the duration "· X yr(s) X mo(s)" and any
  //      work-mode "· Hybrid/On-site/Remote" suffix.
  //   5. The location is whatever's left, if it looks like "City, State".
  //   6. Strip employment type ("Full-time", etc.) from the title.
  const parseExperienceItem = (text) => {
    const cleaned = (text || "").replace(/\s+/g, " ").trim();
    if (!cleaned) return null;

    const monthRe = "(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)";
    const dateStartRe = new RegExp(
      `(?:^|(?<=[ \\t])|(?<=[a-z]))((${monthRe}\\s+\\d{4}|\\d{4}))`,
    );
    const dateStartMatch = cleaned.match(dateStartRe);
    if (!dateStartMatch) {
      return { title: cleaned, company: "", started_at: "", ended_at: "", is_current: false, location: "" };
    }
    const startIdx = dateStartMatch.index;
    const rest = cleaned.slice(startIdx);
    const rangeRe = new RegExp(
      `^(${monthRe}\\s+\\d{4}|\\d{4})\\s*[-–]\\s*(Present|${monthRe}\\s+\\d{4}|\\d{4})`,
    );
    const rangeMatch = rest.match(rangeRe);
    if (!rangeMatch) {
      return { title: cleaned, company: "", started_at: "", ended_at: "", is_current: false, location: "" };
    }
    const endIdx = startIdx + rangeMatch[0].length;

    // The text BEFORE the date is: title + (optional company) + (optional
    // employment type). Split it.
    const before = cleaned.slice(0, startIdx).trim();
    // After the date is: duration + (optional location) + (optional description)
    const afterDate = cleaned.slice(endIdx).trim();

    // Strip employment type from end of before-date text
    const empTypeRe = /\s*[-]?\s*(Full-time|Part-time|Self-employed|Contract|Freelance|Internship|Apprenticeship|Temporary|Volunteer)\s*$/i;
    let beforeClean = before.replace(empTypeRe, "").trim();
    // Also strip trailing bullet separators (· or •)
    beforeClean = beforeClean.replace(/\s*[·•]\s*$/, "").trim();

    // Try to find a company name in the beforeClean text. A company name
    // is one or more capitalized words, optionally with "Inc.", "LLC",
    // "Corp", "Ltd", "LP", "GmbH", "AG", "S.A.", etc.
    // Heuristic: look for a multi-word capitalized phrase that comes
    // AFTER the title (which is the leading words) and BEFORE the date.
    // For format A (no company in text), there is no company here.
    // For format B, the company is the last "word" or phrase.
    let title = beforeClean;
    let company = "";
    // First, try to find a camelCase boundary in beforeClean: a lowercase
    // letter immediately followed by an uppercase letter indicates a
    // word boundary (e.g. "ProgramSpaceX" → "Program" + "SpaceX").
    const camelMatch = beforeClean.match(/^(.+?)([a-z])([A-Z][A-Za-z0-9&.'-]*(?:\s+[A-Z][A-Za-z0-9&.'-]*)*)$/);
    if (camelMatch) {
      // There's a camelCase boundary. The part before the boundary
      // (everything up to and including the lowercase letter) is the
      // title; the part after (the uppercase-led word) is the company.
      title = camelMatch[1] + camelMatch[2];
      company = camelMatch[3].trim();
    } else {
      // No camelCase. Look for a multi-word capitalized company name.
      const companyRe = /^(.+?)\s+([A-Z][\w&.'-]*(?:\s+[A-Z][\w&.'-]*)*(?:\s+(?:Inc|LLC|Ltd|Corp|Corporation|Company|Co|Group|Holdings|Industries|Technologies|Systems|Solutions|Partners|LP|GmbH|AG|S\.A\.|S\.r\.l\.|B\.V\.|Pty)\.?)?)\s*$/;
      const companyMatch = beforeClean.match(companyRe);
      if (companyMatch) {
        const candidate = companyMatch[2];
        const beforeCandidate = companyMatch[1].trim();
        const looksLikeCompany =
          candidate.length >= 3 &&
          candidate.length <= 100 &&
          beforeCandidate.length >= 2 &&
          /^[A-Z]/.test(candidate) &&
          (/\s/.test(candidate) ||
           /\b(Inc|LLC|Ltd|Corp|Co|Group|Holdings|Industries|Technologies|Systems|Solutions|Partners|Company)\b/i.test(candidate));
        if (looksLikeCompany) {
          title = beforeCandidate;
          company = candidate;
        }
      }
    }

    // Strip duration from start of afterDate
    let after = afterDate.replace(
      /^(?:[·•]\s*)?\d+\s*(?:yrs?|mos?)\s*(?:\d+\s*mos?\s*)?/i,
      "",
    ).trim();

    // The remaining text might be: "City, State" + " · Hybrid" + description
    let location = "";
    if (after) {
      // Find the first "·" — everything after it is work mode + description
      const bulletIdx = after.indexOf("·");
      const beforeBullet = bulletIdx >= 0 ? after.slice(0, bulletIdx).trim() : after;
      // Or: stop at a description (sentence with period and capital letter)
      const descMatch = beforeBullet.match(/^(.+?)\.\s+[A-Z]/);
      const candidate = descMatch ? descMatch[1].trim() : beforeBullet;
      // Is it a location?
      if (candidate && (
        /,\s*[A-Z]/.test(candidate) ||
        /Metropolitan|Greater|Bay Area|County/i.test(candidate) ||
        (/^[A-Z][a-z]+(?:\s[A-Z][a-z]+)*$/.test(candidate) && candidate.length < 60)
      )) {
        location = candidate;
      }
    }
    const parts = rangeMatch[0].split(/\s*[-–]\s*/);
    return {
      title,
      company,
      started_at: parts[0] || "",
      ended_at: parts[1] === "Present" ? "" : (parts[1] || ""),
      is_current: parts[1] === "Present",
      location,
    };
  };

  // ── Build the structured payload ──────────────────────────────────────────
  let lastExtracted = null;
  const extract = () => {
    const linkedin_url = window.location.href;
    const linkedin_slug = extractSlug(linkedin_url);

    // Real DOM extraction (the user is logged in with Premium and sees
    // everything they have access to). Strategy: get the experience list
    // first, use the first item as the source of truth for current role,
    // and use the top card for the name + location.
    const experience = extractExperience();
    const full_name = extractName();
    // Prefer the location from the parsed experience item (it's the work
    // location for the current role). Fall back to the top card's primary
    // location only if the experience item has no location.
    let location = "";
    if (experience.length > 0 && experience[0].location) {
      location = experience[0].location;
    }
    if (!location) {
      location = extractLocation();
    }
    // Prefer the experience item's company (it's the most recent role).
    // Only fall back to the top card if the experience item has no company.
    let current_company = "";
    if (experience.length > 0) {
      current_company = experience[0].company || "";
    }
    if (!current_company) {
      current_company = extractCurrentCompanyFromTopCard();
    }
    // Title: only the experience list has it.
    let current_title = "";
    if (experience.length > 0) {
      current_title = experience[0].title;
    }

    log("Name:", full_name);
    log("Title:", current_title);
    log("Company:", current_company);
    log("Location:", location);
    log(`Experience: ${experience.length} role(s)`);

    // Derive first/last name
    const nameParts = (full_name || "").split(/\s+/).filter(Boolean);
    const first_name = nameParts[0] || "";
    const last_name = nameParts.slice(1).join(" ");

    // ALWAYS return a payload, even if extraction was partial. The user can
    // always fill the form fields manually in the popup.
    const payload = {
      linkedin_url,
      linkedin_slug,
      full_name,
      first_name,
      last_name,
      current_title,
      current_company,
      location,
      email: null,
      phone: null,
      experience,
    };
    lastExtracted = payload;
    return payload;
  };

  // ── Highlight-to-extract mode (Phase 3 / t3.1) ────────────────────────────
  // If the user selects text on the page, show a small floating button.
  // On click, capture the selected text + the nearest field-name context.
  let highlightBtn = null;
  const showHighlightButton = (x, y) => {
    if (!highlightBtn) {
      highlightBtn = document.createElement("div");
      highlightBtn.id = "lead-finder-highlight-btn";
      highlightBtn.textContent = "Extract to Lead Finder";
      document.body.appendChild(highlightBtn);
    }
    highlightBtn.style.left = `${x}px`;
    highlightBtn.style.top = `${y}px`;
    highlightBtn.style.display = "block";
  };
  const hideHighlightButton = () => {
    if (highlightBtn) highlightBtn.style.display = "none";
  };
  document.addEventListener("mouseup", (ev) => {
    const sel = window.getSelection();
    const text = sel ? sel.toString().trim() : "";
    if (text.length < 2) {
      hideHighlightButton();
      return;
    }
    showHighlightButton(ev.pageX, ev.pageY);
  });
  document.addEventListener("mousedown", () => hideHighlightButton());
  document.addEventListener("click", (ev) => {
    if (ev.target && ev.target.id === "lead-finder-highlight-btn") {
      const sel = window.getSelection();
      const text = sel ? sel.toString().trim() : "";
      if (text) {
        // Find the nearest field name. Walk up to find a labelled element.
        let anchor = ev.target;
        let label = "";
        for (let i = 0; i < 6 && anchor; i++) {
          // Look for a nearby <dt>, <label>, or a sibling with a known field name.
          const dt = anchor.closest("section, div");
          if (dt) {
            const heading = dt.querySelector("h1, h2, h3, h4, dt, label, [aria-label]");
            if (heading && heading.textContent && heading !== anchor) {
              label = heading.textContent.trim().slice(0, 80);
              break;
            }
          }
          anchor = anchor.parentElement || null;
        }
        chrome.runtime.sendMessage({
          type: "LF_HIGHLIGHT_EXTRACT",
          text,
          context_label: label,
          page_url: window.location.href,
        });
      }
      hideHighlightButton();
    }
  });

  // ── Message handler: respond to popup's "give me the data" request ─────────
  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (!msg || !msg.type) return false;
    if (msg.type === "LF_EXTRACT") {
      const data = lastExtracted || extract();
      sendResponse({ ok: true, data });
      return false; // synchronous
    }
    if (msg.type === "LF_RE_EXTRACT") {
      // Force a fresh extraction (e.g. the user clicked "re-scan").
      const data = extract();
      sendResponse({ ok: !!data, data });
      return false;
    }
    if (msg.type === "LF_PING") {
      sendResponse({ ok: true, on_profile: !!lastExtracted });
      return false;
    }
    return false;
  });

  // ── Debounced MutationObserver for re-extraction ───────────────────────────
  let debounceTimer = null;
  const observer = new MutationObserver(() => {
    if (debounceTimer) clearTimeout(debounceTimer);
    debounceTimer = setTimeout(() => {
      try {
        const fresh = extract();
        if (fresh) {
          chrome.runtime.sendMessage({ type: "LF_DATA_UPDATED", data: fresh }).catch(() => {});
        }
      } catch (e) {
        warn("Re-extract failed:", e);
      }
    }, 500);
  });
  observer.observe(document.body, { childList: true, subtree: true });

  // ── Initial extraction ─────────────────────────────────────────────────────
  // Wait for the page to settle. document_idle already gives us most of the
  // DOM, but LinkedIn lazy-loads the experience section.
  const tryInitialExtract = (attempt = 0) => {
    const data = extract();
    if (!data) return;
    const haveName = !!data.full_name;
    const haveCompany = !!data.current_company;
    const expCount = (data.experience || []).length;
    if (haveName && haveCompany && expCount > 0) {
      log(`Initial extract OK: name=${data.full_name} company=${data.current_company} roles=${expCount}`);
    } else if (attempt < 8) {
      // Partial extract — try again after the page settles
      setTimeout(() => tryInitialExtract(attempt + 1), 500);
    } else {
      warn(
        `Initial extract partial: name=${haveName} company=${haveCompany} roles=${expCount}. ` +
        `The user can still fill the form manually. Try the highlight-to-extract mode: ` +
        `select the name/company with the mouse to capture them.`,
      );
    }
  };
  tryInitialExtract();
})();
