# Chrome Extension — Revision Log

**Purpose:** Track every change to the Lead Finder Chrome extension. **Read this before editing any file in `static/chrome-extension/`.** The previous approach (edit → test → repeat) caused multiple regressions because we had no record of what was working.

**How to use this file:**
1. Before any change, add a new entry under "Open Revisions" with what you plan to do and why
2. After the change works, move the entry to "Closed Revisions" with the actual result
3. If a change regresses something, write a "Regression" entry that points back to the change that caused it
4. Never delete old entries. This is an append-only log.

---

## Open Revisions

(none — see Closed Revisions)

---

## Closed Revisions

### rev-20260724-185300 (targeted fix, content.js = 569 lines)
- **What changed (2 small edits to content.js):**
  1. **Line ~294 in parseExperienceItem:** `\\d{{4}}` → `\\d{4}`. The double-brace was a template-literal typo that produced a broken regex (`{4}` was being parsed as a quantifier on the previous capture group, not as a literal "4 times"). Result: the date-range match always failed, so the entire experience blob was returned as `title` with no other fields populated. This is what caused the Steven Maa symptom: `"Mission Manager, Rideshare ProgramSpaceX · Full-timeJan 2026 - Present · 7 mosHawthorne, California, United States · On-site"` came back as one line.
  2. **Lines ~399-410 in extract():** location discovery now prefers the parsed experience item's location (`experience[0].location`) over the top card's primary location (`extractLocation()`). Previously the top card always won, which gave the wrong location when LinkedIn's "primary location" differs from the work location of the current role.
- **What this should produce on Steven Maa's profile:**
  - `name`: Steven Maa (from `main h2` or og:title)
  - `title`: `Mission Manager, Rideshare Program` (split off from `SpaceX` via camelCase boundary in `parseExperienceItem`)
  - `company`: `SpaceX` (from camelCase split, OR from inner `<a href="/company/spacex">` link if the strategy-2 `<li>` path wins)
  - `started_at`: `Jan 2026`, `ended_at`: ``, `is_current`: true
  - `location`: `Hawthorne, California, United States` (from the experience item's text after the date)
- **Files touched:** `static/chrome-extension/content.js` only. `manifest.json`, `background.js`, `popup.*` unchanged.
- **Verification:** Run on Steven's profile. Console should show `name=Steven Maa`, `title=Mission Manager, Rideshare Program`, `company=SpaceX`, `location=Hawthorne, California, United States`, `1 role(s)`. If anything is wrong, add a regression entry and revert with `tar xzf .revisions/baseline-20260724-185032.tar.gz`.

### baseline-20260724-185032 (baseline snapshot, content.js = 567 lines)
- **What:** Tarball of the current state of all extension files, saved before any further parser work.
- **Why:** Establish a known-good starting point so future regressions can be diffed against this.
- **File:** `static/chrome-extension/.revisions/baseline-20260724-185032.tar.gz`
- **Known problems with this baseline:**
  - **Steven Maa profile (https://www.linkedin.com/in/steven-maa/)**: parser returns the entire experience item as one unparsed string: `"Mission Manager, Rideshare ProgramSpaceX · Full-timeJan 2026 - Present · 7 mosHawthorne, California, United States · On-site"`. No newline/split between title, company, employment type, dates, location, work mode. Form fields stay empty because the title/company aren't extracted from the blob.
  - **Before this baseline (per user):** there was a version that returned `roles=1` and got name + experience count right, but couldn't find the company. The user says: "your previous perfect code (except for the identification of the position for experience content) is now gone. Let's try to get it back and reset. And then make the location change on the discovery for the experience section."
  - **We do not have a copy of the working-but-company-bad version.** It was edited through and the file in this baseline is the regressed state.

### content.js current state (the "regressed" version)
- **Symptom:** `[lead-finder/cs] Initial extract partial: name=true company=false roles=1`
- **Field set by the parser:** name only. title, company, location, experience all empty (the form shows them as blank because the parser joins everything into one blob and never splits it).
- **What broke:** the most recent rewrite attempted to extract from `data-section="currentPositionsDetails"` and `og:` meta tags, but the actual logged-in DOM uses neither pattern for the experience data. The experience items live inside an `<h2>Experience</h2>` section with `<li>` entries, but the parser now joins all text within an item into one string without splitting on newlines or bullet separators.

---

## Known DOM patterns (for reference when designing the next iteration)

| Profile | Connection degree | Experience section structure |
|---|---|---|
| Steven Maa | 1st | `<h2>Experience</h2>` → `<ul class="...">` → `<li>` per role. Each `<li>` has nested divs with title, company link, dates, location, work mode. |
| Jay Malave | 3rd | `<h2>Experience & Education</h2>` → flat `<div>` blocks (no `<ul><li>`). Per user, "third-degree LinkedIn connections show experience data as flat `<div>` blocks". |

The parser must handle BOTH formats. Use the strategy: find the `<h2>Experience</h2>`, then look for either `<ul><li>` children OR direct `<div>` children that contain "Present" in their text.

---

## Revert / recovery

If a new revision breaks things:

1. **Stop.** Don't keep editing.
2. Extract the baseline tarball:

### rev-20260724-213819 (latest-role-only fix, ~80 lines)
- **What:** Reordered `findLatestExperienceItem` to prefer the first `<li>` (Strategy 2) when an `<ul>` exists, with Strategy 1 (leaf-most div with Present) as a fallback for div-only profiles. Added `<li>` walk-up in Strategy 1 so the company link is reachable when the picked div is nested inside an `<li>`.
- **Why:** On Nicole LaMotte's profile (8 SpaceX roles, `<ul><li>` format), Strategy 1 was picking a nested `<div>` whose text was identical to its parent — the leaf-most filter didn't strip it, the sort by length picked the inner div, and the company link (which lives on the `<li>`, not the inner div) was unreachable. Result: popup showed `Role: Manager,`, `Company: Technical Recruiting,`, `Location: Lead Technical Recruiter, Engineering` (two roles joined into one parse).
- **Test cases:**
  - **Nicole LaMotte (https://www.linkedin.com/in/nicole-lamotte-63a21555/)** — Strategy 2 path. Should produce: Role="Manager, Technical Recruiting", Company="SpaceX", Location="Hawthorne, California, United States".
  - **Steven Maa (https://www.linkedin.com/in/steven-maa/)** — Strategy 2 path. Should still produce: Role="Mission Manager, Rideshare Program", Company="SpaceX", Location="Hawthorne, California, United States" (no regression).
  - **Jay Malave (https://www.linkedin.com/in/jay-malave-69a33748/)** — 3rd-degree, div-only. Strategy 1 path. No `<ul>` exists, so it falls through to the leaf-most div. Should still work.
- **Risk:** Low. Two strategy reordering + walk-up. No new selectors. Existing Steven Maa / Jay Malave behavior preserved.
- **Status:** shipped, awaiting user verification on Nicole + Steven + Jay.

### rev-20260724-214346 (Strategy 2 — sub-list guard, ~30 lines)
- **What:** Changed `findLatestExperienceItem` Strategy 2 to use `:scope > ul, :scope > ol` (direct children only) and to skip `<ul>`s whose first `<li>` has neither a date substring nor a `/company/` link.
- **Why:** rev-20260724-213819 didn't fix Nicole. The first `<ul>` walked up from `<h2>Experience</h2>` is a SKILLS or HIGHLIGHTS sub-list, not the experience list. The old code returned its first `<li>` (which has no date, no company link) and then `parseExperienceItem` was being fed the wrong text. Result: popup showed `Location: Technical Recruiting` (end of `<li>` #1's title, picked up as the location because the parse splits on the date) and `Company: Lead Technical Recruiter, Engineering` (the full title of `<li>` #2 because the parse kept reading past the date boundary).
- **Fix details:**
  - `:scope > ul, :scope > ol` — only direct-child `<ul>`s of the current ancestor. Stops the search from picking nested lists inside `<li>`s (like a sub-list of skills within a role).
  - Heuristic gate: at each candidate `<ul>`, the first `<li>` must contain BOTH a date (e.g. "Jan 2026") AND a `/company/` link. If not, it's a skills/highlights/about list — skip it.
  - Loops through all direct-child `<ul>`s at each ancestor level (in case of multiple sibling lists).
- **Test cases:**
  - **Nicole LaMotte** — should now pick the experience `<ul>` (first `<li>` has "Jan 2026 - Present" and an `<a href="/company/spacex">`). Expected popup: Role=`Manager, Technical Recruiting`, Company=`SpaceX`, Location=`Hawthorne, California, United States`.
  - **Steven Maa** — same expected output as rev-20260724-213819 (regression check).
  - **Jay Malave** — div-only profile, Strategy 1 path, no change in behavior.
- **Risk:** Low. Only Strategy 2 changed. Strategy 1 unchanged.
- **Status:** shipped, awaiting user verification.


1. **Stop.** Don't keep editing.
2. Extract the baseline tarball:
   ```bash
   cd /home/anthonyturgman/lead-finder/static/chrome-extension
   tar xzf .revisions/baseline-20260724-185032.tar.gz
   ```
3. Add a Regression entry here pointing to the new revision that broke things.
4. The `/extension/download` endpoint serves whatever is on disk, so after the revert, the user re-syncs and is back to known state.

---

## Next iteration — to be designed

User's stated goal:
1. Get the parser back to the state where it returned `roles=1` (correctly finding the experience item)
2. THEN make one targeted fix: improve **location discovery** inside the experience section

We do not have the previous working version's source. We need either:
- The user to paste the full content.js of the working version, OR
- The user to paste the popup output (form fields populated) from the working version, OR
- A rebuild from the high-level strategy documented in this file

**DO NOT** start a new iteration without one of the above. Confirm with the user before editing.

### rev-20260724-220106 (heading check fix, 1 line changed)
- **What:** Changed `findLatestExperienceItem` line 141 from `=== "Experience"` to accept `"Experience"`, `"Experience & ..."`, or `"Experience, ..."` (any heading that starts with "Experience").
- **Why:** LinkedIn renders the Experience section heading as `"Experience & Education"` on some profiles (when the section is combined with Education). The exact equality check only matched the bare `"Experience"` heading. On Nicole LaMotte's profile, the heading was `"Experience & Education"`, so the check returned null. The parser then fell through to Strategy 1 (the div-based fallback), which picked a div whose text was multiple roles joined — causing the "Manager, / Technical Recruiting" symptom.
- **Root cause analysis:** The 5 summary lines (`Name:`, `Title:`, etc.) were printing because those run at the end of `extract()` regardless. The depth= diagnostic lines were NOT printing because the entire Strategy 2 loop was skipped when `expH2` was null. This explained the "5 lines but no depth= lines" symptom — the parser was reaching the post-extract logging without ever running Strategy 2.
- **Test cases:**
  - **Nicole LaMotte (https://www.linkedin.com/in/nicole-lamotte-63a21555/)** — heading is "Experience & Education". Should now match and pick the first <li> via Strategy 2.
  - **Steven Maa (https://www.linkedin.com/in/steven-maa/)** — heading is bare "Experience". Should still match. No regression.
  - **Jay Malave (https://www.linkedin.com/in/jay-malave-69a33748/)** — heading is bare "Experience" per user, but DOM has "Experience & Education" per curl. Either way, both should now match.
- **Status:** shipped, awaiting user verification.
